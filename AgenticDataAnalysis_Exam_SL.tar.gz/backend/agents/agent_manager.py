import os
import json
import pandas as pd
from typing import List, Dict, Any, Annotated, TypedDict
from langchain_groq import ChatGroq
from langchain_core.messages import HumanMessage, AIMessage, BaseMessage
from langchain_core.tools import tool
from langgraph.graph import StateGraph, END
from langgraph.prebuilt import ToolNode
import plotly.io as pio

from backend.db import models
from backend.security.code_sandbox import execute_code_safely
from backend.core.config import settings

def merge_messages(left: list, right: list) -> list:
    if not left:
        left = []
    if not right:
        right = []
    return left + right

class AgentState(TypedDict):
    messages: Annotated[List[BaseMessage], merge_messages]
    current_variables: Dict[str, Any]
    session_id: int
    user_id: int
    dataset_path: str
    intermediate_outputs: List[Dict[str, Any]]
    output_figures: List[Dict[str, Any]]

# --- Tools Definition ---

# --- Tools Definition ---

@tool
def execute_data_cleaning(thought: str, python_code: str):
    """
    Cleans and transforms the user's dataset.
    Use this for handling missing values, duplicates, and type conversions.
    """
    return "Executed"

@tool
def execute_visualization(thought: str, python_code: str):
    """
    Generates Plotly figures for data visualization.
    The code should append figures to a list named `plotly_figures`.
    Example: `plotly_figures.append(px.histogram(test_dataset, x='score'))`
    """
    return "Executed"

@tool
def execute_statistical_analysis(thought: str, python_code: str):
    """
    Performs statistical analyses (correlations, t-tests, etc.) using pandas/scipy/numpy.
    """
    return "Executed"

# --- Graph Nodes ---

def call_model(state: AgentState):
    from langchain_core.messages import SystemMessage
    import time
    
    # Pace requests to respect Groq rate limits
    time.sleep(2.0)
    
    # Analyze the loaded variables to describe them to the agent
    variable_descriptions = []
    for name, val in state.get("current_variables", {}).items():
        if isinstance(val, pd.DataFrame):
            cols = list(val.columns)
            variable_descriptions.append(
                f"- DataFrame `{name}` is loaded and available. Columns: {cols}. Row count: {len(val)}."
            )
        else:
            variable_descriptions.append(f"- Variable `{name}` is available in the environment.")
            
    variables_str = "\n".join(variable_descriptions) if variable_descriptions else "No DataFrames are currently loaded."
    
    system_prompt = (
        "You are an advanced Agentic Data Analyst capable of cleaning data, performing statistical analysis, "
        "and creating beautiful visualizations using Plotly. You have access to a secure Python execution sandbox.\n\n"
        "### Available Variables in Sandbox:\n"
        f"{variables_str}\n\n"
        "### Guidelines:\n"
        "1. To analyze or clean data, use the `execute_data_cleaning` or `execute_statistical_analysis` tools. "
        "Provide a clear thought explaining what you're doing, and write clean, valid Python code.\n"
        "2. To create visualizations, use the `execute_visualization` tool. The code must append one or more Plotly figure objects "
        "to a list named `plotly_figures` (which is pre-declared in the sandbox). Example: `plotly_figures.append(px.histogram(test_dataset, x='score'))`.\n"
        "3. Ensure that you refer to the DataFrames by their exact variable names (e.g. refer to the loaded DataFrame as the actual name, such as `test_dataset`).\n"
        "4. Avoid generic conversational refusal. If the user asks for analysis, statistical summary, or visualization, use your tools to perform the task."
    )
    
    messages = [SystemMessage(content=system_prompt)] + state["messages"]

    # Using Llama 3.1 8B via Groq for high speed and avoiding rate limits
    model = ChatGroq(
        api_key=settings.GROQ_API_KEY, 
        model="llama-3.1-8b-instant",
        temperature=0.1
    )
    tools = [execute_data_cleaning, execute_visualization, execute_statistical_analysis]
    model_with_tools = model.bind_tools(tools)
    response = model_with_tools.invoke(messages)
    return {"messages": [response]}

def call_tools(state: AgentState):
    """Custom tool node to handle our specialized outputs and execute them in the sandbox"""
    last_message = state["messages"][-1]
    
    new_messages = []
    intermediate_outputs = state.get("intermediate_outputs", []).copy()
    output_figures = state.get("output_figures", []).copy()
    current_variables = state["current_variables"].copy()

    for tool_call in last_message.tool_calls:
        tool_name = tool_call["name"]
        tool_args = tool_call["args"]
        
        python_code = tool_args.get("python_code", "")
        thought = tool_args.get("thought", "")
        
        print(f"--- CALLING TOOL: {tool_name} ---", flush=True)
        print(f"Thought: {thought}", flush=True)
        print(f"Code:\n{python_code}", flush=True)
        
        # Execute code in the sandbox safely using our copied variables
        if tool_name == "execute_visualization":
            result = execute_code_safely(python_code, current_variables)
            print(f"Sandbox Result Success: {result.get('success')}", flush=True)
            print(f"Sandbox Result Error: {result.get('error')}", flush=True)
            print(f"Sandbox Output: {result.get('output')}", flush=True)
            figures_json = [pio.to_json(fig) for fig in result.get("plotly_figures", [])]
            tool_output = {
                "output": result["output"],
                "thought": thought,
                "code": python_code,
                "figures": figures_json,
                "new_variables": result["persistent_vars"]
            }
            output_figures.extend(figures_json)
        elif tool_name in ["execute_data_cleaning", "execute_statistical_analysis"]:
            result = execute_code_safely(python_code, current_variables)
            print(f"Sandbox Result Success: {result.get('success')}", flush=True)
            print(f"Sandbox Result Error: {result.get('error')}", flush=True)
            print(f"Sandbox Output: {result.get('output')}", flush=True)
            tool_output = {
                "output": result["output"],
                "thought": thought,
                "code": python_code,
                "new_variables": result["persistent_vars"]
            }
        else:
            continue
            
        from langchain_core.messages import ToolMessage
        new_messages.append(ToolMessage(
            tool_call_id=tool_call["id"],
            content=json.dumps(tool_output["output"])
        ))
        
        intermediate_outputs.append({
            "thought": tool_output["thought"],
            "code": tool_output["code"],
            "output": tool_output["output"]
        })
        
        if "new_variables" in tool_output:
            current_variables.update(tool_output["new_variables"])

    return {
        "messages": new_messages,
        "current_variables": current_variables,
        "intermediate_outputs": intermediate_outputs,
        "output_figures": output_figures
    }

class AgentManager:
    def __init__(self):
        self.workflow = self._create_workflow()

    def _create_workflow(self):
        workflow = StateGraph(AgentState)
        workflow.add_node("agent", call_model)
        workflow.add_node("tools", call_tools)
        
        workflow.set_entry_point("agent")
        workflow.add_conditional_edges("agent", self._should_continue)
        workflow.add_edge("tools", "agent")
        
        return workflow.compile()

    def _should_continue(self, state: AgentState):
        last_message = state["messages"][-1]
        if last_message.tool_calls:
            return "tools"
        return END

    def process_query(self, db, session_id: int, user_id: int, query: str):
        # 1. Load session context
        session = db.query(models.AnalysisSession).filter(
            models.AnalysisSession.id == session_id,
            models.AnalysisSession.user_id == user_id
        ).first()
        
        if not session:
            raise Exception("Session not found")

        # 2. Reconstruct chat history
        messages = []
        for msg in session.messages:
            if msg.role == "user":
                messages.append(HumanMessage(content=msg.content))
            else:
                messages.append(AIMessage(content=msg.content))
        
        messages.append(HumanMessage(content=query))

        # 3. Load dataset variables
        current_variables = {}
        if session.dataset_id:
            dataset = db.get(models.Dataset, session.dataset_id)
            if dataset:
                df = pd.read_csv(dataset.file_path)
                var_name = dataset.filename.split('.')[0]
                current_variables[var_name] = df

        initial_state = {
            "messages": messages,
            "current_variables": current_variables,
            "session_id": session_id,
            "user_id": user_id,
            "intermediate_outputs": [],
            "output_figures": []
        }

        # 4. Invoke the workflow
        final_state = self.workflow.invoke(initial_state)

        # 5. Persist results
        # Save User Message
        db_user_msg = models.Message(session_id=session_id, role="user", content=query)
        db.add(db_user_msg)
        
        # Save Assistant Response
        assistant_msg = final_state["messages"][-1]
        db_assistant_msg = models.Message(session_id=session_id, role="assistant", content=assistant_msg.content)
        db.add(db_assistant_msg)
        
        db.commit()
        db.refresh(db_assistant_msg)

        # Save Visualizations
        for fig_json in final_state.get("output_figures", []):
            db_viz = models.Visualization(
                session_id=session_id,
                message_id=db_assistant_msg.id,
                figure_json=json.loads(fig_json),
                title="Generated Plot"
            )
            db.add(db_viz)
        
        db.commit()
        
        return {
            "synthesis": assistant_msg.content,
            "figures": [json.loads(fig) for fig in final_state.get("output_figures", [])]
        }
